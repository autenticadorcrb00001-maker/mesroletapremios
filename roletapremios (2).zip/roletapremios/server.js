const express = require("express");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = 3000;

// Middleware para JSON
app.use(express.json());

// Servir arquivos estáticos
app.use("/public", express.static(path.join(__dirname, "public")));
app.use("/painel", express.static(path.join(__dirname, "painel")));
app.use("/assets", express.static(path.join(__dirname, "public/assets")));

// Rota painel
app.get("/painel", (req, res) => {
  res.sendFile(path.join(__dirname, "painel/index.html"));
});

// Rota roleta principal
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public/index.html"));
});

// Caminho fixo do config.json dentro da pasta public
const configPath = path.join(__dirname, "public/config.json");

// Rota para salvar configuração (usada pelo painel)
app.post("/salvar-config", (req, res) => {
  const config = req.body;

  fs.writeFile(configPath, JSON.stringify(config, null, 2), err => {
    if (err) {
      console.error("Erro ao salvar configuração:", err);
      return res.status(500).json({ status: "erro", message: "Não foi possível salvar" });
    }

    console.log("Configuração salva com sucesso!");
    res.json({ status: "ok", message: "Configuração salva" });
  });
});

// Rota para ler configuração (usada pela roleta e pelo painel)
app.get("/config", (req, res) => {
  if (!fs.existsSync(configPath)) return res.json({ premios: [] });

  const configData = fs.readFileSync(configPath);
  res.json(JSON.parse(configData));
});

// Alias para o painel acessar sempre o mesmo config
app.get("/painel/config", (req, res) => {
  if (!fs.existsSync(configPath)) return res.json({ premios: [] });

  const configData = fs.readFileSync(configPath);
  res.json(JSON.parse(configData));
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
  console.log(`Painel: http://localhost:${PORT}/painel`);
  console.log(`Roleta: http://localhost:${PORT}/`);
});
