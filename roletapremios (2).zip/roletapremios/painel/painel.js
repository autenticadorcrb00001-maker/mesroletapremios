// Elementos principais
const listaPremios = document.getElementById("lista-premios");
const btnAddPremio = document.getElementById("add-premio");

// Função para criar um campo de prêmio
function criarPremio(nome = "") {
  const div = document.createElement("div");
  div.classList.add("premio");

  const input = document.createElement("input");
  input.type = "text";
  input.value = nome;
  input.placeholder = "Nome do prêmio";

  const btnRemover = document.createElement("button");
  btnRemover.textContent = "Remover";
  btnRemover.onclick = () => div.remove();

  div.appendChild(input);
  div.appendChild(btnRemover);
  listaPremios.appendChild(div);
}

// Função para carregar configuração do servidor
async function carregarConfig() {
  try {
    const res = await fetch("/config");
    const config = await res.json();

    listaPremios.innerHTML = ""; // limpa lista
    if (config.premios && config.premios.length > 0) {
      config.premios.forEach(p => criarPremio(p));
    }
  } catch (err) {
    console.error("Erro ao carregar configuração:", err);
  }
}

// Função para salvar configuração no servidor
async function salvarConfig() {
  const premios = Array.from(
    listaPremios.querySelectorAll("input")
  ).map(input => input.value.trim()).filter(v => v);

  try {
    const res = await fetch("/salvar-config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ premios })
    });

    const result = await res.json();
    alert(result.message || "Configuração salva!");
  } catch (err) {
    console.error("Erro ao salvar configuração:", err);
    alert("Erro ao salvar configuração!");
  }
}

// Evento para adicionar novo prêmio
btnAddPremio.addEventListener("click", () => criarPremio(""));

// Carregar config ao abrir o painel
carregarConfig();
